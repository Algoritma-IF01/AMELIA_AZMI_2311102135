package main

import (
	"fmt"
	"strconv"
)

func isValidVoucher_135(voucher_135 string) bool {
	length := len(voucher_135)

	if length != 5 && length != 6 {
		return false
	}

	firstDigit, _ := strconv.Atoi(string(voucher_135[0]))
	secondDigit, _ := strconv.Atoi(string(voucher_135[1]))

	lastDigit, _ := strconv.Atoi(string(voucher_135[length-1]))
	secondLastDigit, _ := strconv.Atoi(string(voucher_135[length-2]))

	if (firstDigit * secondDigit) != (lastDigit * secondLastDigit) {
		return false
	}

	var middleDigit int
	if length == 5 {
		middleDigit, _ = strconv.Atoi(string(voucher_135[2]))
	} else {
		middleDigit1, _ := strconv.Atoi(string(voucher_135[2]))
		middleDigit2, _ := strconv.Atoi(string(voucher_135[3]))
		middleDigit3, _ := strconv.Atoi(string(voucher_135[4]))
		middleDigit = middleDigit1 + middleDigit2 + middleDigit3
	}

	if length == 5 {
		return middleDigit%2 == 0
	} else {
		return middleDigit%2 == 0
	}
}

func main() {
	var N int
	fmt.Println("Masukkan jumlah mahasiswa:")
	fmt.Scan(&N)

	validCount := 0
	invalidCount := 0

	for i := 0; i < N; i++ {
		var voucher string
		fmt.Printf("Masukkan nomor seri voucher mahasiswa ke-%d: ", i+1)
		fmt.Scan(&voucher)

		if isValidVoucher_135(voucher) {
			validCount++
		} else {
			invalidCount++
		}
	}

	fmt.Printf("Jumlah voucher valid: %d\n", validCount)
	fmt.Printf("Jumlah voucher tidak valid: %d\n", invalidCount)
}
