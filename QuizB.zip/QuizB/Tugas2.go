package main

import (
	"fmt"
)

func calculateTotal_135(menuCount_135, peopleCount_135 int, leftover_135 bool) int {

	var baseCost int

	if menuCount_135 > 50 {
		baseCost = 100000
	} else if menuCount_135 > 3 {

		baseCost = 10000 + (menuCount_135-3)*2500
	} else {

		baseCost = 10000
	}

	if leftover_135 {
		baseCost *= peopleCount_135
	}

	return baseCost
}

func main() {

	var M int
	fmt.Print("Masukkan jumlah rombongan: ")
	fmt.Scan(&M)

	for i := 0; i < M; i++ {
		var menuCount_135, peopleCount_135 int
		var leftover_135 bool

		fmt.Printf("Masukkan jumlah menu, jumlah orang, dan apakah ada sisa (true/false) untuk rombongan %d: ", i+1)
		fmt.Scan(&menuCount_135, &peopleCount_135, &leftover_135)

		totalCost := calculateTotal_135(menuCount_135, peopleCount_135, leftover_135)

		fmt.Printf("Total biaya untuk rombongan %d: Rp %d\n", i+1, totalCost)
	}
}
