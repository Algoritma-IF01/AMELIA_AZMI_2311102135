package main

import (
	"fmt"
)

func sumMultiplesOf4_135(sum int) int {

	var num int
	fmt.Print("Masukkan bilangan (negatif untuk berhenti): ")
	fmt.Scan(&num)

	if num < 0 {
		return sum
	}

	if num%4 == 0 && num > 0 {
		sum += num
	}

	return sumMultiplesOf4_135(sum)
}

func main() {

	total := sumMultiplesOf4_135(0)

	fmt.Println("Jumlah bilangan kelipatan 4:", total)
}
